#!/bin/sh
#leer archivos de propiedades
#####################################################
nodosfile="./nodos.properties"
glpifile="./glpi.zip"
gefelifile="./gefeli.sh"
scriptgefeli="./scriptgefeli.sh"
clusterfile="./clusterlinux.sh"

#Comprueba la existencia de los archivos.

####################################################

if [ -f "$nodosfile" ];

then
    echo "$nodosfile found"  

else
    echo "$file not found"
fi

####################################################

if [ -f "$glpifile" ];

then
    echo "$glpifile found"
else
    echo "$file not found"
fi
###################################################

if [ -f "$scriptgefeli" ];

then
    echo "$scriptgefeli found"
sudo chmod +x scriptgefeli.sh

else
    echo "$file not found"
fi
##################################################

if [ -f "$gefelifile" ];

then
    echo "$gefelifile found"
sudo chmod +x gefeli.sh

./gefeli.sh
else
    echo "$file not found"
fi

##################################################

if [ -f "$clusterfile" ];

then
    echo "$clusterfile found"
sudo chmod +x clusterlinux.sh

./clusterlinux.sh
else
    echo "$file not found"
fi




