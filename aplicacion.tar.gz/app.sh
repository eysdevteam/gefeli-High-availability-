#!/bin/sh
#leer archivos de propiedades
nodosfile="./nodosserver.properties"
serverfile="./servidoresgefeli.sh"
nfsfile="./nfs.sh"
basedfile="./based_config.php"
#comprueba la existencia de los archivos
if [ -f "$nodosfile" ];

then
    echo "$nodosfile found"
else
    echo "$file not found"
fi
if [ -f "$basedfile" ];

then
    echo "$basedfile found"
else
    echo "$file not found"
fi
if [ -f "$nfsfile" ];

then
    echo "$nfsfile found"
yum -y install wget
wget https://github.com/glpi-project/glpi/releases/download/9.1.3/glpi-9.1.3.tgz
chmod +x nfs.sh
echo "Inicio de script nfs"
./nfs.sh
else
    echo "$file not found"
fi

f [ -f "$serverfile" ];

then
    echo "$serverfile found"
chmod +x servidoresgefeli.sh
echo "Inicio de script servidores gefeli"
./servidoresgefeli.sh
else
    echo "$file not found"
fi




