#!/bin/sh

#DECLARACIÓN DE VARIABLES
#exec &> instalacionservidores.log
FILEHOST=/etc/hosts

#leer archivos de propiedades
file="./nodosserver.properties"
#comprueba la existencia del archivo nodos.properties
if [ -f "$file" ];

then
    echo "$file found"
. $file

else
    echo "$file not found"
fi

echo "Instalación y configuración de glpi 9.1.3"

scp ./glpi.tar.gz root@${hostserver[1]}:/root
scp ./glpi-9.1.3.tgz root@${hostserver[1]}:/root
scp ./based_config.php root@${hostserver[1]}:/root

echo "archivos copiados a nodo 2"

k=0
while [ $k -lt ${#hostserver[@]} ];do
echo "comienza configuracion del host: " ${hostserver[$k]}
ssh root@${hostserver[$k]} "sudo firewall-cmd --zone=public --permanent --add-port=80/tcp"
ssh root@${hostserver[$k]} "sudo firewall-cmd --reload"
echo "firewall modificado y recargado"
ssh root@${hostserver[$k]} "yum -y install httpd php php-mysql php-gd php-mbstring php-ldap wget unzip"
echo "Instalación de paquetes necesarios finalizada"
ssh root@${hostserver[$k]} "systemctl enable httpd"
ssh root@${hostserver[$k]} "systemctl start httpd"
echo "servidor httpd habilitado e iniciado"


fileglpi="./glpi-9.1.3.tgz"

#comprueba la existencia del archivo nodos.properties
if [ -f "$fileglpi" ];

then
    echo "$fileglpi found"
. $fileglpi

else
    echo "$fileglpi not found"

fi


echo "glpi 9.1.3 descargado"
ssh root@${hostserver[$k]} "tar -xvzf glpi-9.1.3.tgz"
echo "glpi 9.1.3 descomprimido"
ssh root@${hostserver[$k]} "mv glpi /var/www/html"
ssh root@${hostserver[$k]} "chown -R apache:apache /var/www/html/glpi/"
ssh root@${hostserver[$k]} "chmod -R 777 /var/www/html/glpi/"
ssh root@${hostserver[$k]} "sed -e '119d' -i /etc/httpd/conf/httpd.conf"
ssh root@${hostserver[$k]} "sed -e '164d' -i /etc/httpd/conf/httpd.conf"
echo "archivo server.cnf modificado"
variable1="/var/www/html/glpi"
ssh root@${hostserver[$k]} "sed '119i\DocumentRoot $variable1 \n ' -i /etc/httpd/conf/httpd.conf"
ssh root@${hostserver[$k]} "sed '164i\    DirectoryIndex /glpi/ \n ' -i /etc/httpd/conf/httpd.conf"
ssh root@${hostserver[$k]} "systemctl restart httpd"
echo "Para continuar el proceso ingrese a la dirección ip  ${hostserver[$k]}, actualice y al concluir oprima cualquier tecla"

read $var1

ssh root@${hostserver[$k]} "sudo cp /var/www/html/glpi/config/config_db.php ~/"

ssh root@${hostserver[$k]} "sudo rm -r /var/www/html/glpi"

echo "Borrado de paquete glpi"

ssh root@${hostserver[$k]} "tar -xzvf glpi.tar.gz"

echo "gefeli descomprimido"

ssh root@${hostserver[$k]} "mv glpi /var/www/html"

ssh root@${hostserver[$k]} "sudo rm -r /var/www/html/glpi/config/config_db.php"

ssh root@${hostserver[$k]} "sudo rm -r /var/www/html/glpi/config/based_config.php"

ssh root@${hostserver[$k]} "mv config_db.php /var/www/html/glpi/config"

ssh root@${hostserver[$k]} "mv based_config.php /var/www/html/glpi/config"

echo "configuración de base de datos finalizada"

ssh root@${hostserver[$k]} "chown -R apache:apache /var/www/html/glpi/"

ssh root@${hostserver[$k]} "chmod -R 777 /var/www/html/glpi/"

echo "permisos de acceso ejecutados"

echo "fin de instalación"

let k=k+1

done
echo "fin de script :o"

